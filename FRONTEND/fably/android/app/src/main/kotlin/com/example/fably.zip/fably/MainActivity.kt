package com.example.fably

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
